# My detailed build notes

I documented my graphics work in GRAPHICS.md, my audio and wireless setup in AUDIO-AND-NETWORK.md, my input/ACPI/USB settings in INPUT-ACPI-AND-USB.md, and my recovery process in REPRODUCTION.md. My original Portuguese notes are also retained.
