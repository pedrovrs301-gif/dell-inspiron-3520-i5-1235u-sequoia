# Realtek Bluetooth 0bda:c829 patch

`RealtekBluetoothFirmware-v1.0.2-dell-c829.patch` is the cumulative diff between the saved upstream v1.0.2 source and the code used for local test 5. It includes USB matching, diagnostics and the firmware/HCI recovery changes. Paths are relative to the upstream project.

Base: https://github.com/thegwchr/RealtekBluetoothFirmware/releases/tag/v1.0.2

On a copy of that base, run `git apply --check` before `git apply`, then follow its Makefile/build instructions and test with a USB EFI first. Patch application was checked during this preparation; recompilation was not performed. Do not apply blindly to current main.

The required NVRAM and BlueToolFixup settings are in the example config and explained in `docs/AUDIO-AND-NETWORK.md`. This patch does not install them by itself. The upstream GPL-2.0-or-later notice is preserved in `third-party/RealtekBluetoothFirmware-LICENSE.txt`.
