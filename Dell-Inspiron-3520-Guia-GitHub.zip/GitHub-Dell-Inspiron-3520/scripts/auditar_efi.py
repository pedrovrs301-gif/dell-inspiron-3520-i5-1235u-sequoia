#!/usr/bin/env python3
"""Audit only the requested EFI folder; never print machine identifiers."""
import argparse
import plistlib
import uuid
from pathlib import Path


def audit(root, personal=False):
    errors = []
    config = root / 'OC/config.plist'
    template = not config.exists()
    if template:
        config = root / 'OC/config.example.plist'
    if not config.is_file():
        return ['Configuração ausente.'], template
    try:
        data = plistlib.loads(config.read_bytes())
    except Exception:
        return ['Configuração não é um plist válido.'], template
    generic = data.get('PlatformInfo', {}).get('Generic', {})
    empty = (
        generic.get('SystemSerialNumber') == ''
        and generic.get('MLB') == ''
        and generic.get('SystemUUID') == '00000000-0000-0000-0000-000000000000'
        and generic.get('ROM') == bytes(6)
    )
    if not personal and not empty:
        errors.append('Identidade preenchida: não publicar este config. Use --personal somente para auditoria privada.')
    if personal and (empty or not generic.get('SystemSerialNumber') or not generic.get('MLB')):
        errors.append('Identidade própria ainda não preenchida.')
    if personal:
        try:
            if uuid.UUID(generic.get('SystemUUID', '')).int == 0:
                errors.append('SystemUUID ainda está zerado.')
        except (ValueError, AttributeError, TypeError):
            errors.append('SystemUUID inválido.')
        if generic.get('ROM') == bytes(6):
            errors.append('ROM ainda está zerada.')
    if not isinstance(generic.get('ROM'), bytes) or len(generic['ROM']) != 6:
        errors.append('ROM precisa ter seis bytes.')
    bt = data.get('NVRAM', {}).get('Add', {}).get('7C436110-AB2A-4BBB-A880-FE41995C9F82', {})
    if len(bt.get('bluetoothInternalControllerInfo', b'')) != 14:
        errors.append('bluetoothInternalControllerInfo precisa ter 14 bytes neste conjunto.')
    paths = []
    for item in data.get('ACPI', {}).get('Add', []):
        if item.get('Enabled'):
            paths.append('OC/ACPI/' + item['Path'])
    for item in data.get('Kernel', {}).get('Add', []):
        if not item.get('Enabled'):
            continue
        base = 'OC/Kexts/' + item['BundlePath'] + '/'
        paths.append(base + item['PlistPath'])
        if item.get('ExecutablePath'):
            paths.append(base + item['ExecutablePath'])
    for item in data.get('UEFI', {}).get('Drivers', []):
        if isinstance(item, dict) and item.get('Enabled'):
            paths.append('OC/Drivers/' + item['Path'])
    paths.extend(['BOOT/BOOTx64.efi', 'OC/OpenCore.efi'])
    for relative in paths:
        destination = root / relative
        if not destination.resolve().is_relative_to(root.resolve()):
            errors.append('Referência de arquivo fora da EFI.')
        elif not destination.is_file() and not template:
            errors.append('Arquivo referenciado ausente: ' + relative)
    if (root / 'Dell').exists():
        errors.append('Pasta Dell presente: remover diagnósticos da cópia pública.')
    return errors, template


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('efi', type=Path)
    parser.add_argument('--personal', action='store_true', help='Validar identidade preenchida, apenas em cópia privada.')
    args = parser.parse_args()
    errors, template = audit(args.efi, args.personal)
    for error in errors:
        print('ERRO:', error)
    if template:
        print('MODELO PÚBLICO: binários ausentes são esperados; esta pasta não inicia o computador.')
    if errors:
        raise SystemExit(1)
    print('Auditoria estrutural concluída. Não comprova boot nem funcionamento do hardware.')
    if not args.personal:
        print('Identidade vazia confirmada. Preencher em uma cópia privada antes de usar.')


if __name__ == '__main__':
    main()
