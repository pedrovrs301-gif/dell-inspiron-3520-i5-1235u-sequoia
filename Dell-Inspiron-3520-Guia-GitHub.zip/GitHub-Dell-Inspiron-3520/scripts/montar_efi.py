#!/usr/bin/env python3
"""Reconstruct the anonymous EFI from an exact local source; no downloads or mounts."""
import argparse
import hashlib
import json
import shutil
import tempfile
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='Pasta EFI completa com os binários do inventário.')
    parser.add_argument('destination', type=Path, help='Pasta EFI nova, que ainda não existe.')
    args = parser.parse_args()
    project = Path(__file__).resolve().parent.parent
    source = args.source.resolve()
    destination = args.destination.resolve()
    if destination.exists() or destination.is_relative_to(source):
        parser.error('O destino deve ser novo e ficar fora da origem.')
    manifest = json.loads((project / 'manifests/EFI-SHA256.json').read_text())
    selected = {}
    for relative, expected in manifest.items():
        candidate = project / 'EFI/OC/config.example.plist' if relative == 'OC/config.plist' else source / relative
        if not candidate.is_file() or not candidate.resolve().is_relative_to(project if relative == 'OC/config.plist' else source):
            parser.error('Arquivo ausente ou referência fora da origem: ' + relative)
        if hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
            parser.error('SHA-256 diferente: ' + relative + '. Não substituir versões silenciosamente.')
        selected[relative] = candidate
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.efi-staging-', dir=destination.parent) as temp:
        staged = Path(temp) / 'EFI'
        for relative, candidate in selected.items():
            target = staged / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(candidate, target)
            if hashlib.sha256(target.read_bytes()).hexdigest() != manifest[relative]:
                raise SystemExit('Falha na conferência da cópia: ' + relative)
        if destination.exists():
            raise SystemExit('Destino passou a existir; nada sobrescrito.')
        staged.rename(destination)
    print('EFI montada e conferida:', len(selected), 'arquivos.')
    print('Identidade vazia. Preencher em cópia privada; validar com ocvalidate e testar pelo pendrive.')


if __name__ == '__main__':
    main()
