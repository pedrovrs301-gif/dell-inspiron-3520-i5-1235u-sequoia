# Public EFI template

This directory is intentionally incomplete for boot. `OC/config.example.plist` has the machine identity removed. The ACPI tables and UTBMap come from my laptop and need review on another hardware revision.

Third-party bootloader/kext binaries are not bundled in this public directory. Their versions and hashes are documented. Read `docs/REPRODUCTION.md` before assembling a private EFI and testing from USB. Graphics and speaker audio also require macOS-side components.
